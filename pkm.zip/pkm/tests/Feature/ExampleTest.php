<?php

it('to go to be true', function () {
    expect(true)->toBe(true);
});
