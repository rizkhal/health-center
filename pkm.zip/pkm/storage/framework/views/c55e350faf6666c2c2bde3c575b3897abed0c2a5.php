<!DOCTYPE html>
<html class="h-full bg-gray-100">

<head>
    <meta charset="UTF-8" />
    <meta
        name="robots"
        content="noindex"
    >
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    />
    <link
        rel="icon"
        type="image/svg+xml"
        href="/favicon.ico"
    >
    <link
        href="<?php echo e(asset('css/app.css')); ?>"
        rel="stylesheet"
    >

    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>

    <script
        defer
        src="<?php echo e(mix('/js/app.js')); ?>"
    ></script>
</head>

<body class="font-sans leading-none text-gray-700 antialiased overflow-x-hidden m-0">
    <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>

    <script
        id="dsq-count-scr"
        src="//portal-berita-1.disqus.com/count.js"
        async
    ></script>

    <?php if(app()->environment('production')): ?>
        <script
            async
            src="https://www.googletagmanager.com/gtag/js?id=UA-235284297-1"
        ></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH /var/www/pkm/resources/views/app.blade.php ENDPATH**/ ?>