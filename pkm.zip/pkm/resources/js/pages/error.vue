<template>
  <div>
    <h1>ERROR</h1>
  </div>
</template>
<script>
import errorLayout from "~/layouts/error.vue";

export default {
  layout: errorLayout,
};
</script>
