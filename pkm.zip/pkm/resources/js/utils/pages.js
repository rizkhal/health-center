const excepts = ["Core::auth/login"];

export { excepts };
