<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KamenTheme\\Providers\\KamenThemeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KamenTheme\\Providers\\KamenThemeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);