<h1 align="center">HEALTH CENTER</h1>

<p align="center">
<a href="https://github.com/rizkhal/health-center/actions/workflows/tests.yml/badge.svg">
<img alt="GitHub tests" src="https://github.com/rizkhal/health-center/actions/workflows/tests.yml/badge.svg">
</a>
<a href="https://github.com/rizkhal/health-center/actions/workflows/php-cs-fixer.yml/badge.svg">
<img alt="GitHub cs fixer" src="https://github.com/rizkhal/health-center/actions/workflows/php-cs-fixer.yml/badge.svg">
</a>
    <a href="https://github.com/rizkhal/health-center/actions/workflows/eslint.yml/badge.svg">
<img alt="GitHub cs fixer" src="https://github.com/rizkhal/health-center/actions/workflows/eslint.yml/badge.svg">
</a>
</p>
