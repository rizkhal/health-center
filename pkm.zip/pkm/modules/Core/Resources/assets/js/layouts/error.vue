<template>
  <div class="bg-red-500">
    <slot />
  </div>
</template>
