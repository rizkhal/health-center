<template>
  <div>REGISTER</div>
</template>
