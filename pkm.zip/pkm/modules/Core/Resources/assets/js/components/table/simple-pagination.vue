<template>
  <span>simple pagination</span>
</template>
