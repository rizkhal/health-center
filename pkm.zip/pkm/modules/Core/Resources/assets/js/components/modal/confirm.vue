<template>
  <div class="p-5 text-center">
    <div
      class="mx-auto flex h-24 w-24 flex-shrink-0 items-center justify-center rounded-full bg-red-200"
    >
      <svg
        id="Layer_1"
        x="0px"
        y="0px"
        viewBox="0 0 457.503 457.503"
        class="h-14 w-14"
        fill="red"
      >
        <path
          d="M381.575,57.067h-90.231C288.404,25.111,261.461,0,228.752,0C196.043,0,169.1,25.111,166.16,57.067H75.929
			c-26.667,0-48.362,21.695-48.362,48.362c0,26.018,20.655,47.292,46.427,48.313v246.694c0,31.467,25.6,57.067,57.067,57.067
			h195.381c31.467,0,57.067-25.6,57.067-57.067V153.741c25.772-1.02,46.427-22.294,46.427-48.313
			C429.936,78.761,408.242,57.067,381.575,57.067z M165.841,376.817c0,8.013-6.496,14.509-14.508,14.509
			c-8.013,0-14.508-6.496-14.508-14.509V186.113c0-8.013,6.496-14.508,14.508-14.508c8.013,0,14.508,6.496,14.508,14.508V376.817z
			 M243.26,376.817c0,8.013-6.496,14.509-14.508,14.509c-8.013,0-14.508-6.496-14.508-14.509V186.113
			c0-8.013,6.496-14.508,14.508-14.508c8.013,0,14.508,6.496,14.508,14.508V376.817z M320.679,376.817
			c0,8.013-6.496,14.509-14.508,14.509c-8.013,0-14.509-6.496-14.509-14.509V186.113c0-8.013,6.496-14.508,14.509-14.508
			s14.508,6.496,14.508,14.508V376.817z"
        />
      </svg>
    </div>
    <div class="mt-5 text-3xl font-semibold">{{ title }}</div>
    <div class="mt-2 leading-7 text-gray-600">
      {{ message }}
    </div>
  </div>
  <div class="mt-4 flex justify-center space-x-2 p-5">
    <button @click.prevent="cancel" type="button" class="btn-close">
      Cancel
    </button>
    <button @click.prevent="accept" class="btn-red" type="button">
      Delete
    </button>
  </div>
</template>
<script>
export default {
  props: {
    title: String,
    message: String,
    accept: Function,
    cancel: Function,
  },
};
</script>
