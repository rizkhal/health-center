export default {
  install: (app, options) => {
    //
  },
};
