<?php

namespace Modules\Core\Listeners\Auth;

class FailedListener
{
    public function handle($event)
    {
        //
    }
}
