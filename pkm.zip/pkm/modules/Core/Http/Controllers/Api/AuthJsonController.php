<?php

namespace Modules\Core\Http\Controllers\Api;

use Illuminate\Http\Request;
use Modules\Core\Abstracts\CoreController;

class AuthJsonController extends CoreController
{
    public function register()
    {
        // code...
    }

    public function login()
    {
        // code...
    }

    public function logout()
    {
        // code...
    }
}
