<?php

namespace Modules\Core\Abstracts;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

/**
 * @OA\Info(
 *     description="Titen API Documentation",
 *     version="1.0.0",
 *     title="Titen API Documentation",
 *     termsOfService="http://swagger.io/terms/",
 *     @OA\Contact(
 *         email="support@titen.org"
 *     ),
 *     @OA\License(
 *         name="Apache 2.0",
 *         url="http://www.apache.org/licenses/LICENSE-2.0.html"
 *     )
 * )
 */
abstract class CoreController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
}
