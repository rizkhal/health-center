<?php

return [
    'name' => 'KamenTheme',

    'table' => [
        'hero' => 'setting_hero',
    ],
];
