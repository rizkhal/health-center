<?php

namespace Modules\KamenTheme\Entities\Setting;

use Illuminate\Database\Eloquent\Model;

class VissionMissionDetail extends Model
{
    protected $guarded = [];

    protected $table = 'setting_vission_mission_details';
}
