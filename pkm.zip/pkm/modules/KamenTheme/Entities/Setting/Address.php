<?php

namespace Modules\KamenTheme\Entities\Setting;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    protected $guarded = [];
}
