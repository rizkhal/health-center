<?php

namespace Modules\KamenTheme\Entities\Setting;

use Illuminate\Database\Eloquent\Model;

class Hero extends Model
{
    protected $table = 'setting_hero';

    protected $guarded = [];
}
