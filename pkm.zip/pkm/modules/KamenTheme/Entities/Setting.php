<?php

namespace Modules\KamenTheme\Entities;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $table = 'kamen_theme_setting_page';

    protected $guarded = [];
}
