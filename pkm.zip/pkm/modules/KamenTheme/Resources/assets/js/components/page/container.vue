<script setup>
//
</script>
<template>
  <div class="mx-auto flex flex-wrap p-8 px-6 xl:px-10">
    <slot />
  </div>
</template>
