<template>
  <kamen-container class="mb-20 flex flex-wrap lg:flex-nowrap lg:gap-10">
    <div class="flex w-full items-center justify-center lg:w-1/2">
      <div>
        <!-- <Image
              src={data.image}
              width="521"
              height="482"
              alt="Benefits"
              layout="intrinsic"
              placeholder="blur"
            /> -->
      </div>
    </div>

    <div class="flex w-full flex-wrap items-center lg:w-1/2 lg:justify-end">
      <div>
        <div class="mt-4 flex w-full flex-col">
          <h3
            class="mt-3 max-w-2xl text-3xl font-bold leading-snug tracking-tight text-gray-800 dark:text-white lg:text-4xl lg:leading-tight"
          >
            mdkwmdkw
          </h3>

          <p
            class="max-w-2xl py-4 text-lg leading-normal text-gray-500 dark:text-gray-300 lg:text-xl xl:text-xl"
          >
            dkwmdkw
          </p>
        </div>

        <!-- <div class="w-full mt-5">
              {data.bullets.map((item, index) => (
                <Benefit key={index} title={item.title} icon={item.icon}>
                  {item.desc}
                </Benefit>
              ))}
            </div> -->
      </div>
    </div>
  </kamen-container>
</template>
