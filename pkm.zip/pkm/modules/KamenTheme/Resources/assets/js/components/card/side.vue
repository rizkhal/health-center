<template>
  <div class="w-full rounded-xl bg-white p-2 shadow">
    <div class="grid grid-cols-6 gap-2">
      <!-- Image -->
      <div class="col-span-2">
        <img src="../../../images/congres.jpeg" class="rounded-xl" />
      </div>

      <!-- Description -->
      <div class="col-span-4">
        <div class="flex flex-col">
          <h1 class="font-bold text-gray-700">Make Global Connections</h1>
          <div class="rounded-xl text-xs font-bold uppercase text-pink-500">
            Congress
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
