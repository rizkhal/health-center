<template>
  <div>
    <h1>SETTING FROM POST MODULE</h1>
  </div>
</template>
