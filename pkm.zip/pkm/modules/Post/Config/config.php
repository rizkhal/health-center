<?php

return [
    'name' => 'Post',

    'migration' => [
        'prefix' => 'post',
    ],
];
